import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MathGenerator } from '../utils/mathGenerator';

const MathQuestion = ({ difficulty, onAnswer, className = "" }) => {
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [mathGenerator] = useState(new MathGenerator(difficulty));

  useEffect(() => {
    generateNewQuestion();
  }, [difficulty]);

  const generateNewQuestion = () => {
    const question = mathGenerator.generateQuestion();
    setCurrentQuestion(question);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const handleAnswerSelect = (answer) => {
    if (showResult) return;
    
    setSelectedAnswer(answer);
    setShowResult(true);
    
    const isCorrect = answer === currentQuestion.correctAnswer;
    
    setTimeout(() => {
      onAnswer(isCorrect);
      generateNewQuestion();
    }, 1500);
  };

  if (!currentQuestion) {
    return (
      <Card className={className}>
        <CardContent className="p-6 text-center">
          <div>載入題目中...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold mb-2">
            <span className="chinese-with-pinyin">
              <span className="pinyin-text">ㄕㄨˋ ㄒㄩㄝˊ ㄊㄧˊ ㄇㄨˋ</span>
              <span className="chinese-text">數學題目</span>
            </span>
          </h3>
          
          <div className="bg-blue-50 p-4 rounded-lg mb-4">
            <div className="text-3xl font-bold text-blue-800 mb-2">
              {currentQuestion.question}
            </div>
            <div className="text-sm text-blue-600">
              {currentQuestion.questionPinyin}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {currentQuestion.options.map((option, index) => {
            let buttonClass = "h-16 text-xl font-semibold transition-all duration-200";
            
            if (showResult) {
              if (option === currentQuestion.correctAnswer) {
                buttonClass += " bg-green-500 text-white";
              } else if (option === selectedAnswer) {
                buttonClass += " bg-red-500 text-white";
              } else {
                buttonClass += " bg-gray-200 text-gray-500";
              }
            } else {
              buttonClass += " bg-white border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 text-gray-800";
            }

            return (
              <Button
                key={index}
                onClick={() => handleAnswerSelect(option)}
                className={buttonClass}
                disabled={showResult}
              >
                {option}
              </Button>
            );
          })}
        </div>

        {showResult && (
          <div className="mt-4 text-center">
            {selectedAnswer === currentQuestion.correctAnswer ? (
              <div className="text-green-600 font-bold text-lg">
                <span className="chinese-with-pinyin">
                  <span className="pinyin-text">ㄉㄚˊ ㄉㄨㄟˋ ㄌㄜ˙！ㄊㄞˋ ㄅㄤˋ ㄌㄜ˙！</span>
                  <span className="chinese-text">答對了！太棒了！</span>
                </span>
              </div>
            ) : (
              <div className="text-red-600 font-bold text-lg">
                <span className="chinese-with-pinyin">
                  <span className="pinyin-text">ㄉㄚˊ ㄘㄨㄛˋ ㄌㄜ˙，ㄗㄞˋ ㄕˋ ㄕˋ ㄎㄢˋ！</span>
                  <span className="chinese-text">答錯了，再試試看！</span>
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MathQuestion;

