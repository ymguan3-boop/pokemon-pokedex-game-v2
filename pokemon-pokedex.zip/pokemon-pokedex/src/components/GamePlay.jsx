import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Book } from 'lucide-react';
import EvolutionChain from './EvolutionChain';
import MathQuestion from './MathQuestion';
import GameStats from './GameStats';

const GamePlay = ({ 
  difficulty, 
  selectedChain, 
  currentEvolution, 
  unlockedStages, 
  correctAnswers,
  consecutiveCorrect,
  totalQuestions,
  showEvolution,
  onAnswer, 
  onBack, 
  onPokedex 
}) => {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* 頂部導航 */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="chinese-with-pinyin">
            <span className="pinyin-text">ㄈㄢˇ ㄏㄨㄟˊ ㄒㄩㄢˇ ㄗㄜˊ</span>
            <span className="chinese-text">返回選擇</span>
          </span>
        </Button>
        
        <Button
          onClick={onPokedex}
          variant="outline"
          className="flex items-center space-x-2 bg-blue-500 text-white hover:bg-blue-600"
        >
          <Book className="w-4 h-4" />
          <div className="text-center">
            <span className="chinese-with-pinyin">
              <span className="pinyin-text">ㄔㄚˊ ㄎㄢˋ ㄊㄨˊ ㄐㄧㄢˋ</span>
              <span className="chinese-text">查看圖鑑</span>
            </span>
          </div>
        </Button>
      </div>

      {/* 進化動畫提示 */}
      {showEvolution && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-lg text-center animate-pulse">
            <div className="text-2xl font-bold text-yellow-600 mb-4">
              <span className="chinese-with-pinyin">
                <span className="pinyin-text">🌟 ㄐㄧㄣˋ ㄏㄨㄚˋ ㄓㄨㄥ... 🌟</span>
                <span className="chinese-text">🌟 進化中... 🌟</span>
              </span>
            </div>
            <div className="text-lg">
              <span className="chinese-with-pinyin">
                <span className="pinyin-text">{selectedChain.chain[currentEvolution].name} ㄓㄥˋ ㄗㄞˋ ㄐㄧㄣˋ ㄏㄨㄚˋ！</span>
                <span className="chinese-text">{selectedChain.chain[currentEvolution].name} 正在進化！</span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 寶可夢進化鏈顯示 */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg mb-6">
        <h2 className="text-xl font-bold text-center mb-4">
          {selectedChain.name}
        </h2>
        <EvolutionChain
          chain={selectedChain.chain}
          unlockedStages={unlockedStages}
          currentEvolution={currentEvolution}
        />
      </div>

      {/* 數學題目 */}
      <div className="bg-white rounded-lg border-2 border-gray-200 p-6">
        <MathQuestion
          difficulty={difficulty}
          onAnswer={onAnswer}
        />
      </div>
    </div>
  );
};

export default GamePlay;

